#include <stdio.h>
#include <string.h>
#include <libmemcached/memcached.h>

#include "radiusd.h"

#ifdef _DNS_ACTION

static memcached_st *memc;
static memcached_return rc;
static memcached_server_st *server;

time_t expiration;
uint32_t  flags;

/*
 *	init the cache server
 */
int _cache_init(char *server, int port)
{
    memc = memcached_create(NULL);
    server = memcached_server_list_append(NULL, server, port, &rc);
    rc = memcached_server_push(memc,server);
    memcached_server_list_free(server);

    return 0;
}

int cache_init()
{
	return _cache_init(config->cacheServer, config->cachePort);
}

int cache_add(char *key, char *value)
{
    rc = memcached_add(memc, key, strlen(key), value, strlen(value), expiration, flags);
    if( rc == MEMCACHED_SUCCESS) {
	return 0;
    }else {
	return -1;
    }
}

int cache_replace(char *key, char *value)
{
    rc = memcached_set(memc, key, strlen(key), value, strlen(value), expiration, flags);
    if( rc == MEMCACHED_SUCCESS) {
	return 0;
    }else {
	return -1;
    }
}

int cache_get(char *key, char *value, int *value_len)
{
    char* result = memcached_get(memc, key, strlen(key), value_len, &flags, &rc);
    if( rc == MEMCACHED_SUCCESS ) {
	memcpy(value, result, *value_len);	
       	return 0; 
    }else {
	return -1;
    }
}

int cache_del(char *key)
{
    rc = memcached_delete(memc, key, strlen(key), expiration);
    if( rc == MEMCACHED_SUCCESS ) {
	return 0;
    }else {
	return -1;
    }
}

int cache_destory()
{
    memcached_free(memc);
    return 0;
}

#endif
